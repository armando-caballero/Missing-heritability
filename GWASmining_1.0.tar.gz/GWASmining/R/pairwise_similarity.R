pairwise_similarity <-
function ( data_set ) {
  
  list_snps = dlply(data_set, .(trait) )
  result = data.frame(levels(data_set$trait))
  colnames(result) = "trait"
  
  for (i in levels(data_set$trait)) {
    
    sub_set = subset (data_set, trait == i)
    result = merge (result, .gene_list_similarity(sub_set, list_snps) )
    
  }
  
  return (result)
  
}
