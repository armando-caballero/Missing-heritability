globalVariables(c("cluster"))

.filter_low_connected_clusters <- function (dis_clusters, similarity) {

  # Remove row corresponding to traits not in a cluster (or in a cluster of size = 1)
  MIN = 2
  tbl = table(dis_clusters$cluster)
  dis_clusters = droplevels(dis_clusters[dis_clusters$cluster %in% names(tbl)[tbl >= MIN],,drop=FALSE])

  # Search for each cluster if there is nodes few connected
  N = length(levels(dis_clusters$cluster))

  for (i in levels(dis_clusters$cluster)) {
    tmp_dis = subset(dis_clusters, cluster==i)
    traits = tmp_dis$trait
    tmp_dis = tmp_dis[,which(names(tmp_dis) %in% tmp_dis$trait)]

    repeat {

      n_nodes = nrow (tmp_dis) # the number of nodes in this cluster
      degree = vector () # a vector of size k with the number of edges of each node
      average = vector () # a vector with the averages similarities for each node

      # calculate for each graph the number of edges in its nodes
      for (j in 1:n_nodes) {
        u=0
        mean_sim = 0
        for (k in 1:n_nodes) {
          if (tmp_dis[j,k] > similarity && j != k) {
            u = u + 1
            mean_sim = tmp_dis[j,k]
          }
          degree[j] = u
          average[j] = mean_sim/u
        }
      }

      #
      if (min(degree) < 0.5*n_nodes) {
        if (length(which(degree==min(degree)))==1) {
          dis_clusters[which(dis_clusters$trait==traits[which(degree==min(degree))]),]$cluster = NA
          tmp_dis = tmp_dis[-which(degree==min(degree)),]
          traits = traits[-which(degree==min(degree))]
          tmp_dis =  tmp_dis[,which(names(tmp_dis) %in% traits)]
        } else {
          min_averages = average [ which(degree==min(degree)) ]
          tmp_dis = tmp_dis[-which(average==min(min_averages)),]
          dis_clusters[which(dis_clusters$trait==traits[which(average==min(min_averages))]),]$cluster = NA
          traits = traits[-which(average==min(min_averages))]
          tmp_dis =  tmp_dis[,which(names(tmp_dis) %in% traits)]
        }
        # modificar dis original dando cluster 0 
      } else {
        break
      }
    }
  }
  return (dis_clusters)
}
