globalVariables(c("functional_domains",
                  "trait.fd"))

add_fd <-function (data) { 

  data %<>% dplyr::mutate (trait.fd = trait)
  fd_names = functional_domains$fd

  enter_fd <- function (trait) {
    repeat{
      writeLines(strwrap(paste("Enter a fisiological group for trait: ", trait, sep="")));
      fd = readLines (n=1);
      if (fd =="quit") {
        stop ("Leaving...")
      } else if (!(fd %in% fd_names)) {
        writeLines(strwrap(paste("Not a valid type. Choose one of: ", stringr::str_c(fd_names, collapse = ", "), ".", sep="")));
        writeLines(strwrap("Or enter 'quit' to exit"));
        writeLines(strwrap(""));
      } else {
        return(fd)
      }
    }
  }

  data %<>% dplyr::group_by(trait, trait.fd) %>% tidyr::nest()
  for (i in 1:nrow(data)) {
    data[i,]$trait.fd = enter_fd (data[i,]$trait)
  }

  data$trait.fd %<>% readr::parse_factor(levels = fd_names)
  data %>% tidyr::unnest()

}
