update_parameters_trait <-
function (X, effect.or.q = "effect") {

  # el trabajo más reciente
  max_count = X[which(X$count==max(X$count)),]
  
  # si miramos "q" y max_count tiene genes con q=NA, 
  # gen y algún valor de frecuencia. Si es así, se le 
  # asigna ese valor en max_count
  if (effect.or.q == "q" && any(is.na(max_count$q))) {
    for (i in max_count$gene) {
      if (is.na(max_count[max_count$gene==i,]$q)) {
        # miramos si otro trabajo (ordenado por N) tiene ése gen y algún valor de frecuencia
        n_works = length(levels(factor(X$count)))
        n_works = n_works-1
        next_count = max(X$count) -1
        get_it = FALSE
        while (n_works > 0 && !get_it) {
          test_count = X[which(X$count==next_count),]
          if ( any(test_count$gene==i) && !is.na(test_count[which(test_count$gene == i),]$q)  ) {
            max_count[which(max_count$gene==i),]$q = test_count[which(test_count$gene==i),]$q
            get_it = TRUE
          } else {
            n_works = n_works - 1
            next_count = next_count -1
          }
        }
        
      }
    }
  }

  return (ddply (X, .(count), function(x) update_parameters_work (x,max_count, effect.or.q) ) )
  
}
