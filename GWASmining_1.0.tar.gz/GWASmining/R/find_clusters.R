find_clusters = function (distance, similarity, count = 1) {
  cluster = vector();
  set_count = count

  # FIRST RAW CLUSTERS
  # loop over each trait
  for (i in 1: nrow(distance)) {
    
    # First graph is numbered 1 by default
    NONE = TRUE
    if (i == 1) {
      cluster[1] = count
      NONE = FALSE
    } else {
      for (j in 2:i) {
        if (distance[i,j] > similarity) {
          cluster[i] = cluster[j-1]
          NONE = FALSE
          break
        }
      }
    }

    if (NONE) {
      count = count + 1
      cluster[i] = count
    }
  }

  # REFINE CLUSTERS
  # Why?: a new cluster number is given everytime when a trait is read and it does not share similariry with a PREVIOUS trait
  # Ej: if A-> C, and B->C, A and C will belong to cluster1, but B may be classified in a separated cluster

  # loop over clusters
  for (i in 1:count) {
    # loop over traits
    for (j in 1:nrow(distance)) {
      # if the trait cluster is different from the cluster being explored
      if (i != cluster[j]) {
        # then we compare that trait with other that do belong to the explored trait
        for (k in 1:nrow(distance)) {
          # in the case that this trait "j" that does not belong to cluster "i" is similar to a trait "k" that does belong to "i", the cluster of "j" is also "i"
          if (i == cluster[k]) {
            if (distance[j,k+1] > similarity) {
              cluster[which(cluster==cluster[j])] = i
              break;
            }
          }
        }
      }
    }
  }

  cluster = factor(cluster)
  nclusters = length(levels(cluster))
  nclusters = nclusters + set_count - 1
  levels(cluster) = seq(from=set_count, to=nclusters)

  trait = data.frame(distance$trait)
  cluster = data.frame(cluster)
  cluster = cbind(cluster,trait)
  colnames(cluster)[2] = "trait"

  return (cluster)
}