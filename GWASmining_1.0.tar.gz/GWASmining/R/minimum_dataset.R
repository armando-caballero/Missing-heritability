minimum_dataset <-
function ( catalog_trait , all.snps=FALSE, index=0, criteria = "date", force_output = FALSE, min.genes=30, cumulative=FALSE ) {

  catalog_trait = droplevels(catalog_trait)

  # LOCAL VARIABLES
  data = data.frame()
  data_cumulative = data.frame()
  count = 0

  # MAXIMUM NUMBER OF STUDYS TO CONSIDER, BY DATE OR POPULATION SIZE
  max_index = length (levels(catalog_trait$pmid))
  if (criteria == "N") {
    max_index = length (unique(catalog_trait$N))
  }

  if (index > max_index) {
    stop ("index argument is higher than total number of works")
  }

  # WHEN OUTPUTING ALL SNPS, index ARGUMENT IS IGNORED AND ALL WORKS ARE CONSIDERED
  if (all.snps) {
    if (index!=0) {
      stop ("index argument should not be defined when using all.snps")
    } else {
      index = max_index
    }
  }

  list = vector()
  if (criteria =="date") {
    list = levels(catalog_trait$pmid)
  } else if (criteria =="N") {
    catalog_trait = catalog_trait [order(-catalog_trait[,"N"]),]
    list = sort(unique(catalog_trait$N))
  } else {
    stop("Ivalidad 'criteria' argument") 
  }

  # For each study i in the list of studies (sorted by date or size)...
  for (i in list) {

    count = count + 1
    print(i)

    # new_data : snps from study i
    if (criteria == "date") {
      new_data = catalog_trait [ which (catalog_trait$pmid==i) , ]
    } else if (criteria == "N") {
      new_data = catalog_trait [ which (catalog_trait$N==i) , ]
    }

    # Append new data to current data (respecting order defined by criteria)
    if (criteria == "date") {
      data = rbind (data , new_data)
      data = data [ order(-data[,"date"]) , ]
    } else if (criteria == "N") {
      data = rbind (new_data , data)
    }

    # Remove duplicated snps or genes (by criteria)
    tmp_data = ddply(data, .(gene), function(x) x[which(x$pvalue == max(x$pvalue)),] )
    tmp_data = ddply(tmp_data, .(gene), function(x) head(x,1))

    if (nrow(tmp_data)>= min.genes || (force_output && index == count) ) {
      if (index==0 || index == count) {
        writeLines(strwrap(paste("Study ",count," of ",max_index,"\n",sep="")))
        data = tmp_data
        if (!all.snps) {
          return(data)
        }
      }
    }

    if (cumulative) {
      cumulative_genes = nrow(tmp_data)
      cumulative_N = head(tmp_data$N,1)
      tmp_cum_data = cbind(tmp_data,count,cumulative_genes,cumulative_N)
      data_cumulative = rbind (data_cumulative,tmp_cum_data)
      print (count)
    }
  }

  if (!force_output && index < count) {
    stop ("Low index number")
  }
  if (!cumulative) {
    return (droplevels(data))
  } else {
    return (droplevels(data_cumulative))
  }
}
