acum_genes <-
function (catalog_trait, criteria = "date") {

  data = data.frame()
  map = ddply(catalog_trait, .(pmid,date, N), summarise, ngenes = 0)

  if (criteria == "date") {
    map = dplyr::arrange(map, date)
    colnames(map)[4] = "acum_ngenes_date"
  } else if (criteria == "N") {
    map = dplyr::arrange(map, N)
    colnames(map)[4] = "acum_ngenes_N"
  } else {
    stop ("Error: Invalid order criteria")
  }

  for (i in 1:nrow(map)) {

    if (criteria == "date") {
      data %<>% rbind (dplyr::filter(catalog_trait, pmid == map[i,]$pmid, date == map[i,]$date))
      map[i,]$acum_ngenes_date = length(unique(data$gene))
    } else if (criteria == "N") {
      data %<>% rbind (dplyr::filter(catalog_trait, pmid == map[i,]$pmid, N == map[i,]$N))
      map[i,]$acum_ngenes_N = length(unique(data$gene))
    }
  }

  return(map)
}
