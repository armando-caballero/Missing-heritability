globalVariables(c("chr", "pos"))

.filter_chr_pos = function ( catalog ) {

  # Remove empty rows
  catalog = dplyr::filter (catalog, chr != "" & pos != "" )

  # Remove rows with interaction ("x") terms
  # If there are several SNPs, check if all CHRs are the same
  # if so, return one chromosome number, and return error otherwise
  catalog$chr = as.character(catalog$chr)
  catalog = catalog[-grep(" x ",catalog$chr,fixed=FALSE),]
  catalog$chr = llply (catalog$chr, strsplit, ";") %>%
    llply(unlist) %>%
    { ifelse ( llply(.,function(x) all(x[[1]] == x)) , ., stop("Error: Found at least one SNP belonging to different chromosomes"))   } %>%
    llply(head,1) %>%
    unlist()
  catalog$chr = factor(catalog$chr)

  # Remove rows with interaction ("x") terms
  # If there are several SNPs, return their average position
  catalog$pos = as.character(catalog$pos)
  catalog = catalog[grepl (" x ", catalog$pos) == FALSE,]
  catalog$pos = llply (catalog$pos, strsplit, ";") %>%
    llply(unlist) %>%
    ifelse (llply(., function(x) if (length(x) > 1) return (1) else return (0) ),
            llply(., function(x) as.character(round(mean(as.numeric(x),na.rm=TRUE)))), . ) %>%
    unlist()
  catalog$pos = factor(catalog$pos)

  return (catalog)
}