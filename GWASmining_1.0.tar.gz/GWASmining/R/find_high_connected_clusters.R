find_high_connected_clusters = function (dis,sim) {
  
  # Find clusters
  clusters = find_clusters(dis,sim)

  # Remove low connected edges
  dis_clusters = merge(clusters,dis)
  filt = .filter_low_connected_clusters(dis_clusters, sim)
  result = subset(filt, !is.na(cluster), select =c("trait","cluster"))
  dis3 = filt[which(is.na(filt$cluster)),]

  while (nrow (filt[which(is.na(filt$cluster)),]) > 0) {
    dis3 = filt[which(is.na(filt$cluster)),]
    trait = dis3$trait
    dis3 = dis3[,which(names(dis3) %in% dis3$trait)]
    dis3 = cbind(trait,dis3)

    next_cluster = max(as.numeric(as.character(result$cluster)))+1
    clusters = find_clusters(dis3,sim, next_cluster)
    dis_clusters = merge(clusters,dis3)
    filt = .filter_low_connected_clusters(dis_clusters, sim)
    result = rbind(result,subset(filt, !is.na(cluster), select =c("trait","cluster")))
    dis3 = filt[which(is.na(filt$cluster)),]
  }

  result$cluster = as.numeric(as.character(result$cluster))
  next_cluster = max(result$cluster)+1
  result$trait = as.character(result$trait)
  remaining_traits = setdiff (dis$trait, result$trait)

  for (i in remaining_traits) {

    result = rbind (result, list(i,next_cluster))
    next_cluster = next_cluster +1
  }

  result$trait = factor (result$trait)
  result = dplyr::arrange(result, cluster)
  result$cluster = factor (result$cluster)
  return (result)
}


