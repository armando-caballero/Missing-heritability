gene_similarity <- function (trait1, trait2) {

  trait1 = droplevels(trait1)
  trait2 = droplevels(trait2)

  return ( ( 2* length( intersect( unique(trait1$gene) , unique(trait2$gene) ) ) ) / ( length(unique(trait1$gene)) + length(unique(trait2$gene)) ) )
}
