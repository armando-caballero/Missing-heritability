.gene_list_similarity <- function (trait, trait_list) {
  result = llply( trait_list, function(x) gene_similarity(x, trait) ) %>%
    ldply(unlist)
  colnames(result) = c("trait", levels(droplevels(trait$trait)))
  return (result)
}
