distribution <-
function (trait , dist = c("gamma","beta","norm","exp","unif","logis","lnorm"), boot = 1000, alpha = 0.05, mode = "exploratory", trait.type = "BETA", qq_test = FALSE, data = data.frame() ) {

  if (trait.type == "OR") {
    trait = trait - 1
  } else if (trait.type != "BETA") {
    stop ("Invalid trait type")
  }

  if (qq_test == TRUE) {
    if (nrow(data) != length(trait)) {
      stop ("Cannot filter data using quantile test")
    }
  }

  trait = trait[which(trait > 0.0)]
  
  # get Cullen and Frey graph
  if (mode == "exploratory") { 
    fitdistrplus::descdist(trait, discrete=FALSE, boot=boot)
  } else if (mode != "analytic" & mode != "filtering") {
    stop ("Invalid mode option")
  } else if (mode == "filtering" & qq_test == FALSE) {
    stop ("QQ_test must be enabled for filtering mode")
  }

  repeat {

    # Use Maximum Likelihhod to fit distributions.
    AIC = vector() # vector of AIC values
    scaled_trait = (trait - min(trait) + 0.001) / (max(trait) - min(trait) + 0.002) # effects scaled to fit the range [0,1], with correlation 1 to the original trait
    #trait = scaled_trait
    for (i in dist) {
      if (i != "beta" && i != "logis") AIC = c(AIC,fitdistrplus::fitdist (trait, i)$aic)
      else             AIC = c(AIC,fitdistrplus::fitdist (scaled_trait, i)$aic)
    }

    dist = dist[which.min(AIC)]

    if (dist != "beta") fit = fitdistrplus::fitdist (trait, dist)
    else                fit = fitdistrplus::fitdist (scaled_trait, dist)

    if (mode == "exploratory") {
      plot (fit) # juntar con la gráfica de cullen, e indicar qué distribución es
    }

    # Perform Kolmogorov-Smirnov non parametric test to check if the data is significantly different from a sample of that distribution or not.

    pdist = paste ("p",dist,sep="")
    kstest = -99.0
  
    # Introduce some noise in the trait, in order to avoid ties in KS-test
    trait = jitter(trait)
  
    if (mode == "exploratory") {
      writeLines(strwrap(paste("Best fit estimates:",sep="")))
    }

    if (dist == "gamma") {
      kstest = ks.test (trait, pdist, shape = fit$estimate["shape"], rate = fit$estimate["rate"])$p.value
      if (mode == "exploratory") {
        writeLines(strwrap(paste("-  shape = ",fit$estimate["shape"],sep="")))
        writeLines(strwrap(paste("-  rate  = ",fit$estimate["rate"],sep="")))
      } else {
        estimates = cbind (dist, parameter1 = fit$estimate["shape"], parameter2 = fit$estimate["rate"], kstest)
      }
    } else if (dist == "beta") {
      kstest = ks.test (trait, pdist, shape1 = fit$estimate["shape1"], shape2 = fit$estimate["shape2"])$p.value
      if (mode == "exploratory") {
        writeLines(strwrap(paste("-  shape1 = ",fit$estimate["shape1"],sep="")))
        writeLines(strwrap(paste("-  shape2= ",fit$estimate["shape2"],sep="")))
      } else {
        estimates = cbind (dist, parameter1 = fit$estimate["shape1"], parameter2 = fit$estimate["shape2"], kstest)
      }
    } else if (dist == "norm") {
      kstest = ks.test (trait, pdist, mean = fit$estimate["mean"], sd = fit$estimate["sd"])$p.value
      if (mode == "exploratory") {
        writeLines(strwrap(paste("-  mean = ",fit$estimate["mean"],sep="")))
        writeLines(strwrap(paste("-  sd   = ",fit$estimate["sd"],sep="")))
      } else {
        estimates = cbind (dist, parameter1 = fit$estimate["mean"], parameter2 = fit$estimate["sd"], kstest)
      }
    } else if (dist == "exp") {
      kstest = ks.test (trait, pdist, rate = fit$estimate["rate"])$p.value
      if (mode == "exploratory") {
       writeLines(strwrap(paste("-  rate  = ",fit$estimate["rate"],sep="")))
      } else {
        estimates = cbind (dist, parameter1 = fit$estimate["rate"], parameter2 = NA, kstest)
      }
    } else if (dist == "unif") {
      kstest = ks.test (trait, pdist, min = fit$estimate["min"], max = fit$estimate["max"])$p.value
      if (mode == "exploratory") {
        writeLines(strwrap(paste("-  min = ",fit$estimate["min"],sep="")))
        writeLines(strwrap(paste("-  max = ",fit$estimate["max"],sep="")))
      } else {
        estimates = cbind (dist, parameter1 = fit$estimate["min"], parameter2 = fit$estimate["max"], kstest)
      }
    } else if (dist == "logis") {
      kstest = ks.test (trait, pdist, location = fit$estimate["location"], scale = fit$estimate["scale"])$p.value
      if (mode == "exploratory") {
        writeLines(strwrap(paste("-  location = ",fit$estimate["location"],sep="")))
        writeLines(strwrap(paste("-  scale    = ",fit$estimate["scale"],sep="")))
      } else {
        estimates = cbind (dist, parameter1 = fit$estimate["location"], parameter2 = fit$estimate["scale"], kstest)
      }
    } else if (dist == "lnorm") {
      kstest = ks.test (trait, pdist, meanlog = fit$estimate["meanlog"], sdlog = fit$estimate["sdlog"])$p.value
      if (mode == "exploratory") {
      
      } else {
        estimates = cbind (dist, parameter1 = fit$estimate["meanlog"], parameter2 = fit$estimate["sdlog"], kstest)
      }
    }

    if (qq_test == TRUE) {
      n = length(trait)
      if (dist == "gamma") {
        theor_quant = qgamma(((1:n)/(n+1)), shape = fit$estimate["shape"], rate = fit$estimate["rate"])
      } else if (dist == "beta") {
        theor_quant = qbeta(((1:n)/(n+1)), shape1 = fit$estimate["shape1"], shape2 = fit$estimate["shape2"])
      } else if (dist == "norm") {
        theor_quant = qnorm(((1:n)/(n+1)), mean = fit$estimate["mean"], sd = fit$estimate["sd"])
      } else if (dist == "exp") {
        theor_quant = qexp(((1:n)/(n+1)), rate = fit$estimate["rate"])
      } else if (dist == "unif") {
        theor_quant = qunif(((1:n)/(n+1)), min = fit$estimate["min"], max = fit$estimate["max"])
      } else if (dist == "logis") {
        theor_quant = qlogis(((1:n)/(n+1)), location = fit$estimate["location"], scale = fit$estimate["scale"])
      } else if (dist == "lnorm") {
        theor_quant = qlnorm(((1:n)/(n+1)), meanlog = fit$estimate["meanlog"], sdlog = fit$estimate["sdlog"])
      }
      lm_model = lm(sort(theor_quant) ~ sort(trait) )
      coef = lm_model$coefficients[2]
      if (coef > 1.15 | coef < 0.85) {
        trait = trait[-which(trait==max(trait))]
        data = data[-which(data$effect==max(data$effect)),]
      } else {
        qq_test = FALSE
      }
    }

    if (qq_test == FALSE) {
      break
    }
  }
    # Print a short summary
    if (mode == "exploratory") {
      writeLines(strwrap(paste("Kolmogorov-Smirnov test gives p-value = ",kstest," for ",dist," distribution",sep="")))
    } else if (mode == "analytic") {
    #estimates$parameter1 = as.numeric(as.character(estimates$parameter1))
    #estimates$parameter2 = as.numeric(as.character(estimates$parameter2))
      return (estimates)
    } else if (mode == "filtering") {
      return (data)
    }

}
