update_parameters_work <-
function (count, max_count, effect.or.q = "effect") {

  if (effect.or.q == "effect") {
    for (i in count$gene) {
      for (j in max_count$gene) {
        if (i==j) {
          count[which(count$gene==i),]$effect = max_count[which(max_count$gene==j),]$effect
          break
        }
      }
    }

  } else if (effect.or.q == "q") {
    for (i in count$gene) {
      for (j in max_count$gene) {
        if (i==j) {
          max_count.q = max_count[which(max_count$gene==j),]$q
          if (!is.na(max_count.q)) {
            count[which(count$gene==i),]$q = max_count.q
          } else {
            
          }
          break
        }
      }
    }
  } else{
    stop("ERROR")
  }
  return (count)
}
