sort_knowledge <- function (catalog_trait, criteria="date", min.genes=30, cumulative=FALSE) {

  catalog_trait %<>%
    dplyr::group_by(cluster, pmid, date, N) %>%
    tidyr::nest()

  if (criteria == "date") {
    catalog_trait %<>% dplyr::arrange(date)
  } else if (criteria == "N") {
    catalog_trait %<>% dplyr::arrange(N)
  } else {
    stop ("Wrong criteria argument: choose 'date' or 'N'.")
  }

  # Step 1. Cumulate SNPs over PMIDs. Removing old 'gene' duplicates.
  # If a gene has a duplicate in the same job, the one with highest pvalue is removed
  sorted_data = catalog_trait[1,]
  for (i in 2:nrow(catalog_trait)) {
    new_data = catalog_trait[i,]
    new_data$data[[1]] %<>%
      dplyr::arrange(desc(pvalue)) %>%
      dplyr::distinct(gene, .keep_all = TRUE)
    new_data$data[[1]] %<>%
      dplyr::bind_rows (sorted_data$data[[1]]) %>%
      dplyr::distinct(gene, .keep_all = TRUE)
    sorted_data = dplyr::bind_rows(new_data, sorted_data)
  }

  # Step 2. Update old gene values with the more recent (and accurate)
  
  # If we only want the new discovered genes, remove the cumulated

  return (sorted_data)
}