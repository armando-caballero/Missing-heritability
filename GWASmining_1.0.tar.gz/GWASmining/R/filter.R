filter <- function (table, value) {

  remove = integer()
  for (i in ncol(table):2) {
    if (!any(table [,i][-(i-1)] >= value)) {
      table[,i] = NULL
      remove = c(remove,i-1)
    }
  }

  table = table [-remove,]

  return (droplevels(table))
}