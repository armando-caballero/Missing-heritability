globalVariables(c("effect",
                  "ci",
                  "snp",
                  "gene",
                  "N",
                  "pmid",
                  "pvalue",
                  "trait",
                  "platform",
                  "N_INI",
                  "N_REP",
                  "europe",
                  "america",
                  "asia",
                  "africa",
                  "eurasia",
                  "V1"))

filter_GWAS_catalog <- function (data, min.pvalue=7.30103, min.N=300, min.genes=30, chr.pos = FALSE, case.control = FALSE, read.pops = FALSE, count.acum.genes = FALSE) {

  ###################
  # INPUT RAW CATALOG
  ###################
  filtred_data = readr::read_tsv ( data, col_types = readr::cols(SNP_ID_CURRENT = "c") ) %>%
    dplyr::select (
      snp = "SNPS",
      gene = "MAPPED_GENE",
      effect = "OR or BETA",
      ci = "95% CI (TEXT)",
      q = "RISK ALLELE FREQUENCY",
      pvalue = "PVALUE_MLOG",
      trait = "DISEASE/TRAIT",
      date = "DATE" ,
      N_INI = "INITIAL SAMPLE SIZE",
      N_REP = "REPLICATION SAMPLE SIZE",
      platform = "PLATFORM [SNPS PASSING QC]",
      pmid = "PUBMEDID",
      chr = "CHR_ID",
      pos = "CHR_POS")

  # Remove unnecesary fields
  if (!chr.pos) {
    filtred_data$chr = NULL
    filtred_data$pos = NULL
  }

  # Indexing catalog
  filtred_data %<>% dplyr::mutate (index = 1:nrow(.))

  # Remove rows with no 'effect' information, 'pvalue', 'trait', 'gene' or 'snp' values
  filtred_data %<>% dplyr::filter (!is.na(effect)) %>%
    dplyr::filter (!is.na(pvalue)) %>%
    dplyr::filter (trait != "") %>%
    dplyr::filter (snp != "") %>%
    dplyr::filter (gene != "")

  # Re-convert variable types: change 'effect' and 'q' factors into numeric (includes NR and string values, which are converted to NAs)
  filtred_data$q %<>% as.double()

  # Infering the type of the effect (BETA or OR)
  filtred_data$ci %<>% stringr::str_remove_all ("[[:punct:]]|[[:digit:]]| |NA|NR|log|odds|od|sd|increase|decrease|variance")

  test.effect.type = ddply(filtred_data,.(pmid, trait),summarize,
                           by_value = factor(ifelse( min(effect, na.rm=TRUE)>=1.0 ,"NA","BETA")),
                           by_units = factor(ifelse( all(grepl("[[:alpha:]]",ci)) ,"BETA","NA")),
                           effect.type = ifelse(by_value=="BETA","BETA",ifelse(by_units=="BETA","NA","OR")) ) %>%
    dplyr::select (pmid, trait, effect.type)

  filtred_data %<>% dplyr::inner_join(test.effect.type)
  filtred_data$effect.type %<>% readr::parse_factor(levels = c("BETA","OR","NA"))
  rm (test.effect.type)
  filtred_data$ci = NULL

  # Reading chromosomal information information
  if (chr.pos) {
    catalog = .filter_chr_pos (catalog)
  }

  # Some punctuation signs are converted
  .edit_punct <- function (string) {
    string %>%
      stringr::str_remove_all(',') %>%
      stringr::str_replace_all('/', '-')
  }

  filtred_data$snp %<>% .edit_punct
  filtred_data$gene %<>% .edit_punct
  filtred_data$trait %<>% .edit_punct
  
  # Get information from sequencing chip, and removing NA values
  filtred_data %<>% dplyr::mutate (imputed = grepl("imputed", platform))
  filtred_data %<>% dplyr::mutate (nchip = platform %>% 
    regmatches(gregexpr('\\(?[0-9]+', .)) %>%
    llply (readr::parse_integer) %>%
    llply (function(x) ifelse(length(x)>0,x,NA)) %>%
    unlist() )
  filtred_data$platform = NULL
  
  # Filtering (=remove) non-significant SNPs
  filtred_data %<>% dplyr::filter (pvalue >= min.pvalue)

  # Population sample sizes
  .clean_pop_data <- function (string) {
    # Boolean expression including all populations

    string %>% ifelse(!is.na(.), .,"0") %>%
      gsub('[A-Za-z],',", ", .) %>%
      gsub ('and ([0-9])',', \\1', .) %>%
      strsplit(", ") %>%
      llply(function(x) gsub ("controls","control",x)) %>%
      llply(function(x) gsub ("cases","case",x)) %>%
      llply(function(x) gsub ('(control)([A-z0-9_ ]+)$','\\1',x)) %>%
      llply(function(x) gsub ('(case)([A-z0-9_ ]+)$','\\1',x)) %>%
      llply(function(x) gsub ('type ([0-9]+)','',x, ignore.case=TRUE)) %>%
      llply(function(x) gsub ('[0-9]/[0-9]','',x)) %>%
      llply(function(x) gsub ('/','-',x)) %>%
      llply(function(x) gsub ('(from|in) [0-9]([A-z0-9_,. ]+)familie','',x)) %>%
      llply(function(x) gsub ('([0-9])\\.([0-9])','\\1,\\2',x) ) %>%
      llply(function(x) gsub ('([0-9]),([0-9])','\\1\\2',x) )
  }

  filtred_data$N_INI %<>% .clean_pop_data
  filtred_data$N_REP %<>% .clean_pop_data

  # Read cases and controls
  if (case.control) {
    .count_case_control <- function (string, key ) {
      if (!(key %in% c("case","control"))) {
        stop ("key argument must be 'case' or 'control'.")
      }
      string %>%
        lapply(function(x) ifelse (grepl (key, x, fixed=TRUE)==TRUE, regmatches(x, gregexpr('\\(?[0-9,.]+', x)),0)) %>%
        llply(unlist) %>%
        llply(readr::parse_integer) %>%
        llply(function(x) sum(x,na.rm=TRUE)) %>%
        unlist()
    }

    filtred_data %<>% dplyr::mutate (N_INI_CASES    = .$N_INI %>% .count_case_control(key="case"),
                                     N_INI_CONTROLS = .$N_INI %>% .count_case_control(key="control"),
                                     N_REP_CASES    = .$N_REP %>% .count_case_control(key="case"),
                                     N_REP_CONTROLS = .$N_REP %>% .count_case_control(key="control"))
  }

  # Read population and continents
  if (read.pops) {

    etnies = stringr::str_c(europe, africa, america, eurasia, asia, collapse ="|") %>%
      stringr::str_c("([A-z0-9 ]*)(", . , ")([A-z0-9 ]*)", sep="")

    .read_pops <- function (string) {
      string %>%
        llply (function(x) gsub("[[:punct:]]","",x)) %>%
        llply (function(x) gsub('([0-9]+)','',x)) %>%
        llply (function(x) gsub('African American','African-American',x)) %>%
        llply (function(x) gsub('Brazillian','Brazilian',x)) %>%
        llply (function(x) gsub('French Canadian','French-Canadian',x)) %>%
        llply (function(x) gsub('Asian Indian','Asian-Indian',x)) %>%
        llply (function(x) gsub('Indian Asian','Indian-Asian',x)) %>%
        llply (function(x) gsub('South Asian','South-Asian',x)) %>%
        llply (function(x) gsub('South East Asian','South-East-Asian',x)) %>%
        llply (function(x) gsub('East Asian','East-Asian',x)) %>%
        llply (function(x) gsub('Northern Finnish','Northern-Finnish',x)) %>%
        llply (function(x) gsub('Han Chinese','Han-Chinese',x)) %>%
        llply (function(x) gsub('Middle Eastern','Middle-Eastern',x)) %>%
        llply (function(x) gsub('ThaiChinese','Thai-Chinese',x)) %>%
        llply (function(x) gsub('Erasmus Ruchpen','Erasmus-Ruchpen',x)) %>%
        llply (function(x) gsub('Ashkenazi Jewish','Ashkenazi-Jewish',x)) %>%
        llply (function(x) gsub('Native American','Native-American',x)) %>%
        llply (function(x) gsub('SubSaharan African','Sub-Saharan-African',x)) %>%
        llply (function(x) gsub('Saudi Arab','Saudi-Arab',x)) %>%
        llply (function(x) gsub('Sri Lankan Sinhalese','Sri-Lankan-Sinhalese',x)) %>%
        llply (function(x) gsub('Finnish','Finland',x)) %>%
        llply (function(x) gsub('Giuli','Giulia',x)) %>%
        llply (function(x) gsub('Rucphen','Ruchpen',x)) %>%
        llply (function(x) gsub('Rupchen','Ruchpen',x)) %>%
        llply (function(x) gsub('Tyrolean','Tyrol',x)) %>%
        llply (function(x) gsub('Hispanic-Latin','Hispanic',x)) %>%
        llply (function(x) gsub('Hispanic-Latino','Hispanic',x)) %>%
        llply (function(x) gsub('Hispanic-Native','Hispanic',x)) %>%
        llply (function(x) gsub('Latino','Latin',x)) %>%
        llply (function(x) gsub('Japnese','Japanese',x)) %>%
        llply (strsplit, " ") %>%
        llply (unlist) %>%
        llply (function(x) ifelse(grepl (etnies, x),gsub(etnies,'\\2',x),"NA") ) %>%
        llply (function(x) x[x!="NA"]) %>%
        llply ( function(x) if(length(x)==0) {"NA"} else {x}) %>%
        llply (unique) %>%
        llply(function(x) do.call (paste, c(as.list(x), sep=" "))) %>%
        unlist()
    }

    filtred_data %<>% dplyr::mutate (N_INI_POPS = .$N_INI %>% .read_pops,
                                     N_REP_POPS = .$N_REP %>% .read_pops,
                                     #N_POPS = N_INI_POPS + N_REP_POPS
                                     )

    .read_cont <- function (string) {
      string %>%
        strsplit(" ") %>%
        llply(function(x) ifelse(grepl(europe,x),"Europe",
                                 ifelse(grepl(africa,x),"Africa",
                                        ifelse(grepl(america,x),"America",
                                               ifelse(grepl(asia,x),"Asia",
                                                      ifelse(grepl(eurasia,x),"Eurasia",x)))))) %>%
        llply(unique) %>%
        llply(function(x) do.call (paste, c(as.list(x), sep=" "))) %>%
        unlist()
      }

      filtred_data %<>% dplyr::mutate (N_INI_CONT = .$N_INI_POPS %>% .read_cont,
                                       N_REP_CONT = .$N_REP_POPS %>% .read_cont,
                                       #N_CONT = N_INI_CONT + N_REP_CONT
                                       )
  }

  # Calculate total number of individuals
  .get_sum_int <- function (string) {
    string %>%
      llply(function(x) regmatches(x, gregexpr('\\(?[0-9,.]+', x))) %>%
      llply(unlist) %>%
      llply (as.integer) %>%
      llply(sum, na.rm=TRUE) %>%
      unlist()
  }
  filtred_data$N_INI %<>% .get_sum_int
  filtred_data$N_REP %<>% .get_sum_int
  filtred_data %<>% dplyr::mutate (N = N_INI + N_REP)

  # Remove rows with few sampled individuals
  filtred_data %<>% dplyr::filter (N >= min.N)
  
  # Remove traits with few unique genes
  filtred_data %<>% dplyr::filter(trait %in% 
                                    (ddply (filtred_data, .(trait), summarize, N=length(unique(gene))) %>%
                                    dplyr::filter (N >= min.genes) %>%
                                    .$trait))

  # Remove traits with few genes, separating traits by type effect (OR,BETA)
  filtred_data %<>% dplyr::mutate (trait.effect.type = paste (trait, effect.type, sep = "-"))
  filtred_data %<>% dplyr::filter (trait.effect.type %in%
                                     (ddply(filtred_data, .(trait.effect.type), summarize, N = length(gene)) %>%
                                     dplyr::filter(N >= min.genes) %>%
                                     .$trait.effect.type))

  # When a trait has both BEAT and OR measures, drop the SNPs whose effect type is less represented.
  review.traits = ddply ( filtred_data, .(trait), summarise, types = length(unique(trait.effect.type)), n_or = length(grep("OR", trait.effect.type)), n_beta = length(grep("BETA", trait.effect.type))) %>% dplyr::filter(types > 1)
  for (i in 1:nrow(review.traits)) {
    if (review.traits[i,]$n_or > review.traits[i,]$n_beta) {
      filtred_data %<>% dplyr::filter(!(trait == review.traits[i,]$trait && effect.type == "BETA"))
    } else {
      filtred_data %<>% dplyr::filter(!(trait == review.traits[i,]$trait && effect.type == "OR"))
    }
  }
  filtred_data$trait.effect.type = NULL
  rm (review.traits)

  # Count the number of unique and cumulated genes found by work
  filtred_data %<>% dplyr::inner_join ( ddply (filtred_data, .(pmid, trait), summarise, ngenes = length(unique(gene))))
  if (count.acum.genes) {
    filtred_data %<>% dplyr::inner_join ( ddply (filtred_data, .(trait), acum_genes, "date" ) )
    filtred_data %<>% dplyr::inner_join ( ddply (filtred_data, .(trait), acum_genes, "N" ) )
  }

  return (filtred_data)
}
