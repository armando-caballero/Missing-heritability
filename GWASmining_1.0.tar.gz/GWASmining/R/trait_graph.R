globalVariables(c("name"))

trait_graph = function (dis, sim, catalog, clusters=NULL) {

  # En clusters el orden de traits debe ser el mismo que en dis ¿juntar? clases S4
  nodes = dplyr::select(dis,trait)
  nodes = ddply(nodes,.(trait), function(x) levels(droplevels(dplyr::filter (catalog, as.character(trait)==x$trait)$trait.type)))
  colnames(nodes) = c("name","fd")

  ngenes = ddply (catalog, .(trait), function(x) length(unique(x$gene)) )
  colnames(ngenes)= c("name","ngenes")
  nodes = merge(nodes, ngenes)
  nodes$ngenes = nodes$ngenes / max(nodes$ngenes)

  names.map = dplyr::transmute(nodes, trait=name, id=1:nrow(nodes))
  nodes = cbind(nodes, 1:nrow(nodes))
  colnames (nodes)[ncol(nodes)] = "id"
  nodes$name = nodes$id

  # FIND THE EDGES
  from = vector()
  to = vector()
  weight = vector()

  for (i in 2:nrow(dis)) {
    for (j in 2:(i)) {
      if (dis[i,j] > sim) {
        if (is.null(clusters) || (clusters$cluster[i] == clusters$cluster[j-1])) {
          from[length(from)+1] = as.character(nodes$name[i])
          to[length(to)+1] = as.character(nodes$name[j-1])
          weight[length(weight)+1] = as.numeric(dis[i,j])
        }
      }
    }
  }

  edges = data.frame(cbind(from,to))
  edges = cbind(edges, weight)
  nodes = merge(nodes,functional_domains) # x es un dataframe con fd y color, debe ser global
  nodes = subset(nodes, select=c(2,1,3,4,5))

  net = graph_from_data_frame(d=edges, vertices=nodes, directed=FALSE)

  plot (net,
        vertex.color= adjustcolor(V(net)$color, alpha.f = 0.5),
        vertex.size = 30*V(net)$ngenes, # (3/min(V(net)$ngenes))*V(net)$ngenes
        vertex.frame.color=adjustcolor(V(net)$color, alpha.f = 0.75),
        vertex.label = V(net)$id,
        vertex.label.color="black",
        vertex.label.cex=0.8,
        vertex.label.dist = 0,
        edge.width = 3* E(net)$weight,
        edge.curved=0.2)
}
